<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="<?php echo e(asset('assets/fontawesome/css/all.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-light.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-regular.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-solid.css')); ?>" rel="stylesheet" type="text/css">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .actions {
            opacity: 0;
            /* Hide actions by default */
        }

        .item:hover {
            background-color: #f5f5f5;
            /* Change background color on hover */
        }

        .item:hover .actions {
            opacity: 1;
            /* Show actions on hover */
        }
    </style>
        <script>
            function confirmDelete(event) {
                event.preventDefault(); // Prevent the form from submitting immediately
                const userConfirmed = confirm('Do you really want to delete this?');
                if (userConfirmed) {
                    event.target.submit(); // Submit the form if the user confirmed
                }
            }
        </script>
</head>

<body class="flex w-full">
    <?php if (isset($component)) { $__componentOriginalc2de825d4e33209ddffb818784ae7904 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2de825d4e33209ddffb818784ae7904 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-bar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2de825d4e33209ddffb818784ae7904)): ?>
<?php $attributes = $__attributesOriginalc2de825d4e33209ddffb818784ae7904; ?>
<?php unset($__attributesOriginalc2de825d4e33209ddffb818784ae7904); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2de825d4e33209ddffb818784ae7904)): ?>
<?php $component = $__componentOriginalc2de825d4e33209ddffb818784ae7904; ?>
<?php unset($__componentOriginalc2de825d4e33209ddffb818784ae7904); ?>
<?php endif; ?>
    <div class="w-full h-screen overflow-y-auto">
        <div class="text-right bg-gray-800 text-gray-100 p-4">
            <span class="text-sm">Welcome, <?php echo e(Auth::user()->name); ?></span>
            <i class="fa-sharp fa-light fa-user inline-block rounded-full ml-2" alt="Profile picture"></i>
        </div>
        <!-- Content -->
        <div class="flex-1 p-10 w-full">
            <div class="flex-1 p-6">
                <h1 class="text-3xl font-semibold">We’ve Worked With (Hotssports)</h1>
                <div class="flex justify-between items-center my-6">
                    <div class="text-xl font-bold">
                        All (<?php echo e($companies->count()); ?>)
                    </div>
                    <a href="<?php echo e(route('companies.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Add
                        New</a>

                </div>

                <!-- Display Success Message -->
                <?php if(session('success')): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative"
                        role="alert">
                        <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                    </div>
                <?php endif; ?>


                <?php if($companies->isEmpty()): ?>
                    <div class="border-t item flex flex-col bg-white p-4 hover:bg-gray-200">
                        <div class="flex justify-between items-center mt-2">
                            <div class="w-full flex items-center">
                                <span class="font-bold">No Company logo available.</span>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border-t item flex justify-between items-center bg-white p-4 hover:bg-gray-200">
                            <div class=" mt-2 flex items-center">
                                <?php if($company->image): ?>
                                    <div class="mt-4">
                                        <img src="<?php echo e(asset('storage/' . $company->image)); ?>" alt="<?php echo e($company->name); ?>"
                                            class="w-20 h-auto">
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="actions ml-6">
                                <div class="w-full flex mt-2">
                                    <a href="<?php echo e(route('companies.edit', $company->id)); ?>"
                                        class="bg-blue-600 text-white px-4 py-2 rounded mr-2 hover:bg-blue-500">Edit</a>
                                    <form action="<?php echo e(route('companies.destroy', $company->id)); ?>" method="POST" onsubmit="confirmDelete(event)"
                                        class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\hotsportstv\resources\views/logos/index.blade.php ENDPATH**/ ?>