    <div class="w-1/8 h-screen bg-gray-800 text-gray-100">
        <div class="p-4 whitespace-nowrap font-bold"> <i class="fa-solid fa-house-chimney"></i> HSM Admin Panel</div>
        <nav class="text-sm">
            <a href="/dashboard" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fa-sharp fa-solid fa-gauge mr-2"></i> Dashboard
            </a>
            <a href="/blog-list" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-pen mr-2"></i> Posts
            </a>
            <a href="/categories" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-pen mr-2"></i>Blog Categories
            </a>
            <a href="/projects" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-project-diagram mr-2"></i> HS Projects
            </a>
            <a href="/hprojects" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-project-diagram mr-2"></i> Hotsports Projects
            </a>
            <a href="/team" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-users mr-2 "></i> The Team
            </a>
            <a href="/media" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-photo-video mr-2"></i> Media
            </a>
            <a href="/testimonials" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fa-solid fa-people-line mr-2"></i> Testimonials
            </a>
            <a href="<?php echo e(route('instagram-posts.index')); ?>" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fa-solid fa-people-line mr-2"></i> Instagram Post
            </a>
            <a href="<?php echo e(route('companies.index')); ?>" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fa-solid fa-people-line mr-2"></i> Companies (Hotssports)
            </a>
            <a href="<?php echo e(route('pcompanies.index')); ?>" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fa-solid fa-people-line mr-2"></i> Companies (Primedia)
            </a>
        </nav>
        <div>
        <!-- Authentication -->
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>

            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                this.closest(\'form\').submit();']); ?>
                <?php echo e(__('Log Out')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
        </form>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\hotsportstv\resources\views/components/side-bar.blade.php ENDPATH**/ ?>