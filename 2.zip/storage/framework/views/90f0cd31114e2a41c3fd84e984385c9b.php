<!-- dashboard.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device="width=device-width", initial-scale="1.0">
    <title>Dashboard</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Font Awesome -->
    
    <link href="<?php echo e(asset('assets/fontawesome/css/all.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-light.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-regular.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-solid.css')); ?>" rel="stylesheet" type="text/css">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .actions {
            opacity: 0 /* Hide actions by default */
        }

        .item:hover{
            background-color: #f5f5f5; /* Change background color on hover */
        }

        .item:hover .actions {
            opacity: 1; /* Show actions on hover */
            
        }
    </style>
</head>

<body class="flex w-full">
    <div class="w-1/8 h-screen bg-gray-800 text-gray-100">
        <div class="p-4 whitespace-nowrap font-bold"> <i class="fa-solid fa-house-chimney"></i> HSM Admin Panel</div>
        <nav class="text-sm">
            <a href="/dashboard" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fa-sharp fa-solid fa-gauge"></i> Dashboard
            </a>
            <a href="#" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-pen"></i> Posts
            </a>
            <a href="#" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-project-diagram"></i> Projects
            </a>
            <a href="#" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-users"></i> The Team
            </a>
            <a href="#" class="block py-2.5 px-4 hover:bg-gray-700">
                <i class="fas fa-photo-video"></i> Media
            </a>
        </nav>
    </div>
    <div class="w-full h-screen overflow-y-auto  ">
        <div class="text-right bg-gray-800 text-gray-100 p-4">
            <span class="text-sm">Welcome, Uche</span>
            <i class="fa-sharp fa-light fa-user inline-block rounded-full ml-2" alt="Profile picture"></i>

        </div>
          <!-- Content -->
          <div class="flex-1 p-10 w-4/6">

            <h1 class="text-2xl font-bold mb-6">Create Team</h1>
            <!-- Form -->
            <form class="space-y-4 mt-4">
                <input type="text" placeholder="Team Member's Name" class="w-full p-2 border border-gray-300 rounded">
                <input type="text" placeholder="Role / Designation" class="w-full p-2 border border-gray-300 rounded">
                <div class="flex items-center">
                    <input type="file" id="upload" class="hidden">
                    <label for="upload" class="w-full p-2 border border-gray-300 ">Upload New Cover Image Here</label>
                    <button type="button" class="py-2 px-4 text-white bg-blue-500  ">Upload</button>
                </div>


                <div class="flex justify-start space-x-4 mt-4">
                    <button type="button" class="py-2 px-4 text-white bg-blue-500 rounded">Publish</button>
                    <button type="button" class="py-2 px-4 text-white bg-pink-500 rounded">Save to Drafts</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\hotsportstv\resources\views/Media/Create.blade.php ENDPATH**/ ?>