<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Font Awesome -->
    
    <link href="<?php echo e(asset('assets/fontawesome/css/all.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-light.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-regular.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-solid.css')); ?>" rel="stylesheet" type="text/css">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .file-input-container {
            position: relative;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
        }

        .file-input-label {
            flex-grow: 1;
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 0.25rem;
            background-color: #fff;
            cursor: pointer;
            text-align: center;
        }

        .file-input-button {
            padding: 0.5rem 1rem;
            background-color: #3490dc;
            color: #fff;
            border: none;
            border-radius: 0.25rem;
            cursor: pointer;
            margin-left: 0.5rem;
        }

        .file-input {
            display: none;
        }

        .file-name {
            margin-left: 1rem;
            font-size: 0.875rem;
            color: #555;
            margin-top: 0.5rem;
        }
    </style>
</head>

<body class="flex w-full">
    <?php if (isset($component)) { $__componentOriginalc2de825d4e33209ddffb818784ae7904 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2de825d4e33209ddffb818784ae7904 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-bar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2de825d4e33209ddffb818784ae7904)): ?>
<?php $attributes = $__attributesOriginalc2de825d4e33209ddffb818784ae7904; ?>
<?php unset($__attributesOriginalc2de825d4e33209ddffb818784ae7904); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2de825d4e33209ddffb818784ae7904)): ?>
<?php $component = $__componentOriginalc2de825d4e33209ddffb818784ae7904; ?>
<?php unset($__componentOriginalc2de825d4e33209ddffb818784ae7904); ?>
<?php endif; ?>
    <div class="w-full h-screen overflow-y-auto  ">
        <div class="text-right bg-gray-800 text-gray-100 p-4">
            <span class="text-sm">Welcome, <?php echo e(Auth::user()->name); ?></span>
            <i class="fa-sharp fa-light fa-user inline-block rounded-full ml-2" alt="Profile picture"></i>

        </div>
        <!-- Content -->
        <div class="flex-1 p-10 w-4/6">

            <h1 class="text-2xl font-bold mb-6">Add Media File</h1>



            <!-- Display Validation Errors -->
            <?php if($errors->any()): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- Form -->
            <form action="<?php echo e(route('media.store')); ?>" method="POST" enctype="multipart/form-data"
                class="space-y-4">
                <?php echo csrf_field(); ?>

                   <select name="page" id=""  class="w-full p-2 border border-gray-300 rounded">
                        <option value="" disabled selected>Select Page</option>
                        <option value="Homepage">Home Page</option>
                        <option value="HotSports">HotSports</option>
                        <option value="HS-Studios">HS-Studios</option>
                        <option value="Our Companies">Our Companies</option>
                        <option value="Primedia">Primedia</option>
                        <option value="Studios">Studios</option>
                        <option value="Team-Page">Team-Page</option>

                        
                    </select>

                <input type="text" name="category" placeholder="Enter Image Category"
                    class="w-full p-2 border border-gray-300 rounded">

                <div class="file-input-container">
                    <label for="upload" class="file-input-label">Upload Company Logos</label>
                    <input type="file" id="upload" name="images[]" class="file-input" multiple>
                    <button type="button" class="file-input-button">Upload</button>
                    <div id="file-names" class="file-name">No files selected</div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Save</button>
                </div>
            </form>
        </div>
    </div>
</body>
<script>
    document.getElementById('upload').addEventListener('change', function() {
        var fileNames = [];
        for (var i = 0; i < this.files.length; i++) {
            fileNames.push(this.files[i].name);
        }
        document.getElementById('file-names').textContent = fileNames.length > 0 ? fileNames.join(', ') :
            'No files selected';
    });

    document.querySelector('.file-input-button').addEventListener('click', function() {
        document.getElementById('upload').click();
    });
</script>

</html>
<?php /**PATH C:\xampp\htdocs\hotsportstv\resources\views/media/create.blade.php ENDPATH**/ ?>