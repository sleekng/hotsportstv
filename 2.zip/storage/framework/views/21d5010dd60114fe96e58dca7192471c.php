<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testimonials</title>


    
    <!-- Font Awesome -->
    
    <link href="<?php echo e(asset('assets/fontawesome/css/all.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-light.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-regular.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fontawesome/css/sharp-solid.css')); ?>" rel="stylesheet" type="text/css">


    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .actions {
            opacity: 0;
        }

        .item:hover {
            background-color: #f5f5f5;
        }

        .item:hover .actions {
            opacity: 1;
        }
    </style>
        <script>
            function confirmDelete(event) {
                event.preventDefault(); // Prevent the form from submitting immediately
                const userConfirmed = confirm('Do you really want to delete this?');
                if (userConfirmed) {
                    event.target.submit(); // Submit the form if the user confirmed
                }
            }
        </script>
</head>

<body class="flex w-full">
    <?php if (isset($component)) { $__componentOriginalc2de825d4e33209ddffb818784ae7904 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2de825d4e33209ddffb818784ae7904 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-bar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2de825d4e33209ddffb818784ae7904)): ?>
<?php $attributes = $__attributesOriginalc2de825d4e33209ddffb818784ae7904; ?>
<?php unset($__attributesOriginalc2de825d4e33209ddffb818784ae7904); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2de825d4e33209ddffb818784ae7904)): ?>
<?php $component = $__componentOriginalc2de825d4e33209ddffb818784ae7904; ?>
<?php unset($__componentOriginalc2de825d4e33209ddffb818784ae7904); ?>
<?php endif; ?>
    <div class="w-full h-screen overflow-y-auto">
        <div class="text-right bg-gray-800 text-gray-100 p-4">
            <span class="text-sm">Welcome, <?php echo e(Auth::user()->name); ?></span>
            <i class="fa-sharp fa-light fa-user inline-block rounded-full ml-2" alt="Profile picture"></i>
        </div>
        <div class="flex-1 p-10 w-full">
            <h1 class="text-3xl font-semibold">Testimonials</h1>
            <div class="flex justify-between items-center my-6">
                <div class=" text-xl font-bold">
                    All (<?php echo e($testimonials->count()); ?>)
                </div>
                <a href="<?php echo e(route('testimonials.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Add New</a>
                <div>
                    <input type="text" placeholder="Search Testimonials" class="border p-2 ml-4 rounded-lg" />
                    <button class="bg-blue-500 text-white px-4 py-2 ml-2 rounded-lg">Search</button>
                </div>
            </div>

            <!-- Display Success Message -->
<?php if(session('success')): ?>
<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
</div>
<?php endif; ?>



            <div class="bg-gray-100 p-4 rounded-t flex mt-4 justify-between items-center">
                <div class="w-full flex items-center">
                    <span class="font-bold">Testimonials</span>
                </div>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border-t item flex flex-col bg-white p-4 hover:bg-gray-200">
                    <div class="flex justify-between items-center mt-2">
                        <div class="w-1/2 flex items-center">
                            <span class="font-bold"><?php echo e($testimonial->author); ?></span>
                        </div>
                    </div>
                    <div class="w-1/2 flex items-center">
                        <span ><?php echo $testimonial->content; ?></span>
                    </div>
                    <div class="actions ml-6">
                        <div class="w-full flex mt-2">
                            <a href="<?php echo e(route('testimonials.edit', $testimonial->id)); ?>" class="bg-blue-600 text-white px-4 py-2 rounded mr-2 hover:bg-blue-500">Edit</a>
                            <form action="<?php echo e(route('testimonials.destroy', $testimonial->id)); ?>" method="POST" class="inline-block" onsubmit="confirmDelete(event)">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="border-t item flex flex-col bg-white p-4 hover:bg-gray-200">
                    <div class="flex justify-between items-center mt-2">
                        <div class="w-full flex items-center">
                            <span class="font-bold">No testimonials available.</span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\hotsportstv\resources\views/testimonials/index.blade.php ENDPATH**/ ?>