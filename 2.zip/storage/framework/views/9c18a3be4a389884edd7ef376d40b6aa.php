

<?php $__env->startSection('content'); ?>
    <h1>All Media</h1>
    <a href="<?php echo e(route('media.create')); ?>">Upload New Media</a>
    <ul>
        <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('media.show', $item->id)); ?>"><?php echo e($item->title); ?></a>
                <form action="<?php echo e(route('media.destroy', $item->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotsportstv\resources\views/Media/Index.blade.php ENDPATH**/ ?>